demo-book
=========

Demo book to see how github-bookeditor works. If you want to start your own book, fork empty-book.

To see the editor with this book, go to http://editor.oerpub.org/#repo/oerpub/demo-book.
Fork the book to save changes and see the editor in action. Code for the editor is in at https://github.com/oerpub/github-bookeditor.

To view the book online in a very simple epub-viewer here - oerpub.github.io/demo-book. 

You can see a prototype PDF generation service for this book here - http://pdf.oerpub.org. The code for that service is here: https://github.com/philschatz/pdf-ci


