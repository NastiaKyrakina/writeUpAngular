import { UkrDatesPipe } from './ukr-dates.pipe';

describe('UkrDatesPipe', () => {
  it('create an instance', () => {
    const pipe = new UkrDatesPipe();
    expect(pipe).toBeTruthy();
  });
});
