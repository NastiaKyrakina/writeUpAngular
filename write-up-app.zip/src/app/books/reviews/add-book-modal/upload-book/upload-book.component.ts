import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-book',
  templateUrl: './upload-book.component.html',
  styleUrls: ['./upload-book.component.scss']
})
export class UploadBookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
